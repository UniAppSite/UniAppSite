// Import Firebase modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.5.0/firebase-app.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.5.0/firebase-auth.js";

// Firebase configuration
const firebaseConfig = {
    //YOUR FIREBASE CONFIG GOES HERE
   };

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Function to check authentication and handle user state
function checkAuthState() {
    // Access onAuthStateChanged from the imported module
    onAuthStateChanged(auth, (user) => {
        if (!user) {
            // User is not logged in, redirect to login page
            console.log("No user found, redirecting to login page");
            window.location.href = "login.html";
        } else {
            // User is logged in, update welcome message
            console.log("User logged in:", user.email);
            const welcomeMessage = document.getElementById("welcome-message");
            if (welcomeMessage) {
                welcomeMessage.innerText = `Welcome, Logged In as ${user.email}`;
            }
        }
    });
}

// Initialize authentication check when DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log("DOM loaded, checking auth state");
    checkAuthState();
});